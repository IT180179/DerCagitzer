# Cagitzer

Reservierungsplattform die sowohl von Mitarbeitern als auch von Kunden genutzt werden kann. Leichterer Reservierungsvorgang und übersichtlichere Darstellung der Reservierungen. Responsive und corperate Design für die Web-Anwendung bedienbar für alle Altersgruppen. Alle Termine einhalten, konfliktfreies Arbeiten und Zufriedenheit des Kunden.

Das Gasthaus Cagitz verfügt derzeit über kein Reservierungsprogramm. Reservierungen werden handschriftlich in einem Buch eingetragen und sind sehr unübersichtlich. Deshalb wurden wir vom Gasthaus Cagitz beauftragt ein webbasiertes Reservierungsprogramm für Kunden und Mitarbeiter zu entwickeln. Mit diesem Reservierungssystem wollen wir dem Gasthaus Cagitz und dessen Kunden die Reservierung vereinfachen.